// ASM2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <vector>
#include "Coffee.h"
#include "Decorator.h"
#include "System.h"

using namespace std;

int main()
{
	System s;
	s.run();
}